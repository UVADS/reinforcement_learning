### Roadmap

1) rl_fundamentals
2) cart_pole1_basics_and_simple_policy
3) k_armed_bandit
4) approaches_to_solving_mdps1_dynamic_programming
5) approaches_to_solving_mdps2_monte_carlo
6) approaches_to_solving_mdps3_temporal_difference
7) q_learning
8) models_and_planning
9) deep_q_networks
10) policy_gradients
11) cart_pole2_policy_gradient
12) resources_for_doing_deeper
